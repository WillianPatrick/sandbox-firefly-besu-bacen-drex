# Changelog

## v0.0.28

- Binary builds handled by goreleaser