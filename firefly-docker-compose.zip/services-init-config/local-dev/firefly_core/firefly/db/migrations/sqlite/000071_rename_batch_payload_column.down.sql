ALTER TABLE batches RENAME COLUMN manifest TO payload;
