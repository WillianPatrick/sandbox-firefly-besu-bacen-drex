DROP INDEX tokenbalance_uri;
