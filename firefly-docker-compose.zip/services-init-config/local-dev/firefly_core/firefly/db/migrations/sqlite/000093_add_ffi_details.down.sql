ALTER TABLE ffimethods DROP COLUMN details;
ALTER TABLE ffievents DROP COLUMN details;
