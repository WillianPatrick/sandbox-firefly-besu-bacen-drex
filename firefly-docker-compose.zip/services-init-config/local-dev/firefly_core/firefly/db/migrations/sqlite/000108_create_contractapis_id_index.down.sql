DROP INDEX contractapis_id;
