ALTER TABLE tokenpool DROP COLUMN decimals;
