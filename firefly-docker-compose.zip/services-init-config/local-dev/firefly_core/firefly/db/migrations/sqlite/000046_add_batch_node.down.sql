ALTER TABLE batches DROP COLUMN node_id;
