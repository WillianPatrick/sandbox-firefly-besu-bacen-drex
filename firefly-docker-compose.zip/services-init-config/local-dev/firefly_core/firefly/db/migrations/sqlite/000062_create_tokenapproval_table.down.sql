DROP TABLE IF EXISTS tokenapproval;
