ALTER TABLE operations DROP COLUMN retry_id;
