ALTER TABLE messages ADD COLUMN reject_reason TEXT DEFAULT '';
