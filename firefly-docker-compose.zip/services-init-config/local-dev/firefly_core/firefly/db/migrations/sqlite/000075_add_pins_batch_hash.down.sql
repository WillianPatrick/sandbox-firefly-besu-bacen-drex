ALTER TABLE pins DROP COLUMN batch_hash;
