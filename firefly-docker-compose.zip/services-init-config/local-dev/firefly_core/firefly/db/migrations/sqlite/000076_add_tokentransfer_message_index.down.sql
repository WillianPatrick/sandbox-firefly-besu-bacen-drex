DROP INDEX tokentransfer_messageid;
