DROP INDEX transactions_id;
