ALTER TABLE tokenpool DROP COLUMN standard;
