ALTER TABLE batches DROP COLUMN "key";
ALTER TABLE messages DROP COLUMN "key";
ALTER TABLE tokenpool DROP COLUMN "key";
