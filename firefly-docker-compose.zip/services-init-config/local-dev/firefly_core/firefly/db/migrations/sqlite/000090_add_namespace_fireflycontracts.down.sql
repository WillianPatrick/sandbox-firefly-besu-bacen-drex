ALTER TABLE namespaces DROP COLUMN firefly_contracts;
