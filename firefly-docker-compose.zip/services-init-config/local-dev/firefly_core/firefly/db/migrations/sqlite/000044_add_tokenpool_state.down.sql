ALTER TABLE tokenpool DROP COLUMN state;
