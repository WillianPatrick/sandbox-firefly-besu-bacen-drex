DROP TABLE IF EXISTS messages_data;

