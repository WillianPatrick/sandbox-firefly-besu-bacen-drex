ALTER TABLE operations ADD COLUMN retry_id UUID;
