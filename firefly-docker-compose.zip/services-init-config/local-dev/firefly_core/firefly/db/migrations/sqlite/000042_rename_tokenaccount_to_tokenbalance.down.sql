ALTER TABLE tokenbalance RENAME TO tokenaccount;
