DROP TABLE IF EXISTS blockchainevents;
