DROP TABLE IF EXISTS operations;

