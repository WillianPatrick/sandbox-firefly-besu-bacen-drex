ALTER TABLE ffimethods ADD COLUMN details TEXT;
ALTER TABLE ffievents ADD COLUMN details TEXT;
