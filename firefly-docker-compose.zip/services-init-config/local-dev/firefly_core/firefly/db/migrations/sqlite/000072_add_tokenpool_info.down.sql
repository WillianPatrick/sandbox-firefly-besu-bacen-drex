ALTER TABLE tokenpool DROP COLUMN info;
