DROP INDEX pins_batch;
