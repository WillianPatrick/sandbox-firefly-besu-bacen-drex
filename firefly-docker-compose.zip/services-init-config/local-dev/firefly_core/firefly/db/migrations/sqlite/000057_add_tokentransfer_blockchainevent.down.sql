ALTER TABLE tokentransfer DROP COLUMN blockchain_event;
