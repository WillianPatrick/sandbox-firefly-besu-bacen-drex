DROP TABLE IF EXISTS namespaces;

