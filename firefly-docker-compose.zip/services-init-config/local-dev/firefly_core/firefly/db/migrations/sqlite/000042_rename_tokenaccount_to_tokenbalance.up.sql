ALTER TABLE tokenaccount RENAME TO tokenbalance;
