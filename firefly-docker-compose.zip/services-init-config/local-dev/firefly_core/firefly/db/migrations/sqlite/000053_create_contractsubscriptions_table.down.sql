DROP TABLE IF EXISTS contractsubscriptions;
