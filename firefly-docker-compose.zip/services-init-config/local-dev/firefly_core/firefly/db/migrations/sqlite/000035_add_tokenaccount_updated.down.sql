ALTER TABLE tokenaccount DROP COLUMN updated;
