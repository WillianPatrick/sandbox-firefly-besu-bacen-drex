BEGIN;
ALTER TABLE tokenaccount DROP COLUMN namespace;
ALTER TABLE tokentransfer DROP COLUMN namespace;
COMMIT;
