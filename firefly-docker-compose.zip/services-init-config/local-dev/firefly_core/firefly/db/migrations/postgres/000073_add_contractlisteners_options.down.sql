BEGIN;
ALTER TABLE contractlisteners DROP COLUMN options;
COMMIT;