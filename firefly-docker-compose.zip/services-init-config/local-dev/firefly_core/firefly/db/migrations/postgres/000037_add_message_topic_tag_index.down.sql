BEGIN;
DROP INDEX messages_topics_tag;
COMMIT;
