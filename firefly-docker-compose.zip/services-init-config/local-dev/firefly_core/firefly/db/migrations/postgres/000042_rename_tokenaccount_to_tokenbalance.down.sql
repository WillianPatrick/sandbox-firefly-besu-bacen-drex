BEGIN;
ALTER TABLE tokenbalance RENAME TO tokenaccount;
COMMIT:
