BEGIN;
DROP INDEX tokenbalance_uri;
COMMIT;
