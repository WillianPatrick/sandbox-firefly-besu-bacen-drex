BEGIN;
DROP INDEX contractapis_id;
COMMIT;
