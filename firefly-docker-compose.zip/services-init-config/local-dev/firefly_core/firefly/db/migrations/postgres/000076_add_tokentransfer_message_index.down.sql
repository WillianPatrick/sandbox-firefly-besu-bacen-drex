BEGIN;

DROP INDEX tokentransfer_messageid;

COMMIT;
