BEGIN;
DROP INDEX blockchainevents_protocolid;
COMMIT;
