BEGIN;
ALTER TABLE namespaces DROP COLUMN firefly_contracts;
COMMIT;
