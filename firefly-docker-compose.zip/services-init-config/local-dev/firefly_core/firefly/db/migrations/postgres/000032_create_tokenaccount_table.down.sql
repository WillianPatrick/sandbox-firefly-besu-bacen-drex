BEGIN;
DROP TABLE tokenaccount;
COMMIT;
