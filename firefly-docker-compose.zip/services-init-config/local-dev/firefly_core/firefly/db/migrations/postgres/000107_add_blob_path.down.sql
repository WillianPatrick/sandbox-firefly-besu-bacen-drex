BEGIN;
DROP INDEX data_blob_path;
ALTER TABLE data DROP COLUMN blob_path;
COMMIT;