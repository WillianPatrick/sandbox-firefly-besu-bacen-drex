BEGIN;
DROP TABLE IF EXISTS contractsubscriptions;
COMMIT;