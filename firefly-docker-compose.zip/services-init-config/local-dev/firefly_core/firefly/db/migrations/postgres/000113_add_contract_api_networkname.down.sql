BEGIN;
DROP INDEX contractapis_networkname;
ALTER TABLE contractapis DROP COLUMN published;
ALTER TABLE contractapis DROP COLUMN network_name;
COMMIT;
