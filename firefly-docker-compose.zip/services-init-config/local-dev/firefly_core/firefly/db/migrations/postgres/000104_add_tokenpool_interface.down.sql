BEGIN;
ALTER TABLE tokenpool DROP COLUMN interface;
ALTER TABLE tokenpool DROP COLUMN interface_format;
ALTER TABLE tokenpool DROP COLUMN methods;
COMMIT;
