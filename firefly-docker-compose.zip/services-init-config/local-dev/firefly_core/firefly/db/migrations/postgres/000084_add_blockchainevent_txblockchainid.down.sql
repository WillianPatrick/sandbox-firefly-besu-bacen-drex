BEGIN;
DROP INDEX blockchainevents_txblockchainid;
ALTER TABLE blockchainevents DROP COLUMN tx_blockchain_id;
COMMIT;
