BEGIN;
ALTER TABLE contractapis DROP COLUMN message_id;
COMMIT;
