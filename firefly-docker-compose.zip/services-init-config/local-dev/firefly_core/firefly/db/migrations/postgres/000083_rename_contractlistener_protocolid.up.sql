BEGIN;
ALTER TABLE contractlisteners RENAME COLUMN protocol_id TO backend_id;
COMMIT;
