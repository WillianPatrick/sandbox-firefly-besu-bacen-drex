BEGIN;

DROP INDEX transactions_id;

COMMIT;
